import React from "react";
import { Link } from "react-router-dom";
import logo from "../assets/logo.webp";

const Header = () => {
  return (
    <>
      
      <div className=" p-2">
        <nav className='m-2 p-4 justify-end border border-red-200 shadow-2xl  rounded-3xl bg-red-400'>
              <div>
                {/* <img className="flex w-15 h-20 rounded-3xl flex-row p-5" src={logo} alt="Swiggy logo" /> */}
                <Link className="p-10 font-semibold " to="/">Home</Link>
                <Link className="p-10 font-semibold " to="/about">About</Link>
                <Link className="p-10 font-semibold " to="/contact">Contact </Link>
              </div>
        </nav>
      </div>
    </>
  );
};

export default Header;