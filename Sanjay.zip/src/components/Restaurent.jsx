import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'

const Restaurent = () => {
    const {resId}=useParams()
    const [products,setProducts]=useState("")
    useEffect(() => {
        (async()=>{
            const data=await fetch('https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=11.0168445&lng=76.9558321&restaurantId=331001')
          const json=await data.json()
          console.log(json)
          })()
    }, [])
    // const fetchdata=async()=>{
    //   const data=await fetch('https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=11.0168445&lng=76.9558321&restaurantId=331001')
    // const json=await data.json()
    // console.log(json)
    // }
    
  return (
    <>
            
            <h1>
            <div>Restaurent {resId}</div>
            </h1>
    </>


  )
}

export default Restaurent